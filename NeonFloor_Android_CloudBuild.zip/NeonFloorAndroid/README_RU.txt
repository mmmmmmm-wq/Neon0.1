NEON FLOOR — ANDROID PROJECT

В проект встроен улучшенный HTML-файл игры в app/src/main/assets/index.html.
Приложение открывает игру во встроенном Android WebView:
- горизонтальная ориентация;
- полноэкранный режим без панелей браузера;
- JavaScript и DOM Storage включены;
- рекорд localStorage сохраняется на устройстве;
- сеть и дополнительные разрешения не требуются.

КАК СОБРАТЬ APK
1. Установите Android Studio (версия с поддержкой Android Gradle Plugin 8.7.3).
2. Откройте в Android Studio папку NeonFloor (именно папку проекта, не HTML).
3. Дождитесь синхронизации Gradle и установки Android SDK Platform 35.
4. Выберите Build → Build Bundle(s) / APK(s) → Build APK(s).
5. APK будет создан в app/build/outputs/apk/debug/app-debug.apk.

Для публикации используйте Build → Generate Signed Bundle / APK.

СБОРКА БЕЗ КОМПЬЮТЕРА (ЧЕРЕЗ ТЕЛЕФОН)
1. Создайте аккаунт GitHub и новый пустой репозиторий.
2. Распакуйте ZIP на телефоне (например, через файловый менеджер).
3. Загрузите ВСЕ файлы и папки из NeonFloorAndroid в корень репозитория GitHub.
   Важно: загрузите также скрытую папку .github/workflows с файлом build-apk.yml.
4. Откройте вкладку Actions в репозитории. Если GitHub попросит разрешить Actions, подтвердите.
5. Выберите Build Neon Floor APK → Run workflow.
6. После завершения откройте запуск workflow, внизу раздел Artifacts и скачайте NeonFloor-debug-apk.
7. Распакуйте скачанный artifact ZIP — внутри будет app-debug.apk. Откройте APK и разрешите установку из этого источника, если Android спросит.

Сборка выполняется на серверах GitHub; Android Studio и компьютер не нужны. Для загрузки файлов удобнее включить в браузере режим «Версия для ПК».
